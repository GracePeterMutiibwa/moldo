from .core import ParserInterface as MoldoParser
